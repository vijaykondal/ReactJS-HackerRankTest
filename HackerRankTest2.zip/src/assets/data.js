const data = [
    {
        "country": "india",
        "city": "delhi"
    },
    {
        "country": "Londaon",
        "city": "Cigago"
    }, {
        "country": "China",
        "city": "delhi2"
    }, {
        "country": "india2",
        "city": "delhi"
    }, {
        "country": "india3",
        "city": "delhi"
    }, {
        "country": "india4",
        "city": "delhi"
    }, {
        "country": "india",
        "city": "delhi"
    },
    {
        "country": "Londaon",
        "city": "Cigago"
    }, {
        "country": "China",
        "city": "delhi2"
    }, {
        "country": "india2",
        "city": "delhi"
    }, {
        "country": "india3",
        "city": "delhi"
    }, {
        "country": "india4",
        "city": "delhi"
    },
    {
        "country": "india",
        "city": "delhi"
    },
    {
        "country": "Londaon",
        "city": "Cigago"
    }, {
        "country": "China",
        "city": "delhi2"
    }, {
        "country": "india2",
        "city": "delhi"
    }, {
        "country": "india3",
        "city": "delhi"
    }, {
        "country": "india4",
        "city": "delhi"
    }

]

const data2 = [
    {
        "name": "Philistan",
        "location": "Delhi",
        "age": "23"
    },
    {
        "name": "Rajiv",
        "location": "Gujart",
        "age": "43"
    }, {
        "name": "Rajs",
        "location": "Kolkata",
        "age": "23"
    },
    {
        "name": "Roshan Kumar",
        "location": "Phil",
        "age": "27"
    }
]

export { data, data2 }