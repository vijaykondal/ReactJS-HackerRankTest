import React from "react";
const Table = ({ data }) => {
    console.log(data);
    return (
        <div className="card">
            <table data-testid="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Age</th>
                    </tr>
                </thead>
                {data.length > 0 && (
                    <tbody data-testid="tableBody">
                        {data.map((prod) => {
                            return (
                                <tr key={Math.random()}>
                                    <td>{prod.name}</td>
                                    <td>{prod.location}</td>
                                    <td>{prod.age}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                )}
            </table>
        </div>
    );
};
export default Table;