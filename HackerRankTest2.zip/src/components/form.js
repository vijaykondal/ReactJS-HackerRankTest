// myForm.js
import React, { useState } from 'react'
import { Formik, Field, Form } from 'formik'

const sleep = ms => new Promise(r => setTimeout(r, ms))

export const MyForm = ({ fun }) => {
    // const handleSubmit = async values => {
    //     await sleep(500)
    //     //  onSubmit(formData)
    // }
    const [formData, setFormdata] = useState({
        fname: '',
        lname: '',
        email: ''
    })
    const handleSubmit = () => {
        fun(formData)
        console.log(formData)
    }
    const [show, setShow] = useState(false)
    const handleSubmit1 = () => {
        setShow(true)
    }

    const handleChange = (e) => {
        setFormdata({ ...formData, ...{ [e.target.name]: e.target.value } })

    }
    return (
        <div>
            <h1>Sign Up</h1>
            {show && <p>hello</p>}
            {/* <Formik
                initialValues={{
                    firstName: '',
                    lastName: '',
                    email: '',
                }}
                onSubmit={handleSubmit}
            >
                <Form>
                    <label htmlFor="firstName">First Name</label>
                    <Field id="firstName" name="firstName" placeholder="Jane" />

                    <label htmlFor="lastName">Last Name</label>
                    <Field id="lastName" name="lastName" placeholder="Doe" />

                    <label htmlFor="email">Email</label>
                    <Field
                        id="email"
                        name="email"
                        placeholder="jane@acme.com"
                        type="email"
                    />
                    <button type="submit">Submit</button>
                </Form>
            </Formik> */}

            <form >
                <input type='text' placeholder='first name' name='fname' onChange={handleChange} />
                <input type='text' placeholder='last name' name='lname' onChange={handleChange} />
                <input type='email' placeholder='email' name='email' onChange={handleChange} />
                <button type='submit' name="submit" onClick={handleSubmit}>submit</button>
                <button name='testClick' data-testid='testButton' onClick={handleSubmit1}>submit1</button>
            </form>
        </div>
    )
}