import { useState } from "react";

const Navigation = () => {

    const [output, setOutput] = useState('HOME PAGE')
    const hangelRout = (content) => {
        setOutput(content)
    }

    return (
        <div>
            <nav>
                <a href="#" onClick={() => { hangelRout('HOME PAGE') }}> Home</a>
                <a href="#" onClick={() => { hangelRout('NEW PAGE') }}> New Page</a>
                <a href="#" onClick={() => { hangelRout('ABOUT US') }}> About</a>
            </nav>
            <div>
                <span>{output}</span>
            </div>
        </div>
    )

}

export default Navigation;