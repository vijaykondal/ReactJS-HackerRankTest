// myForm.test.js
import React from 'react'
import { getByRole, render, screen, waitFor } from '@testing-library/react'
import user from '@testing-library/user-event'

import { MyForm } from './form.js'

test('rendering and submitting a basic Formik form', async () => {
    const handleSubmit12 = jest.fn()
    render(<MyForm fun={handleSubmit12} />)
    // const user = userEvent.setup()

    await user.type(screen.getByPlaceholderText(/first name/i), 'John')
    await user.type(screen.getByPlaceholderText(/last name/i), 'Dee')
    await user.type(screen.getByPlaceholderText(/email/i), 'john.dee@someemail.com')

    await user.click(screen.getByRole('button', { name: 'submit' }))

    await waitFor(() =>
        //  expect(handleSubmit).toBeCalled(),
        expect(handleSubmit12).toHaveBeenCalledWith({
            email: 'john.dee@someemail.com',
            fname: 'John',
            lname: 'Dee',
        }),
    )
})

it('on render hello not show', async () => {
    render(<MyForm />)
    expect(screen.queryByText('hello')).not.toBeInTheDocument()
})

it('handle click function', async () => {
    render(<MyForm />)
    await user.click(screen.getByTestId('testButton'))
    // await user.click(screen.getByRole('button', { name: 'testClick' }))
    expect(screen.getByText('hello')).toBeInTheDocument()
})