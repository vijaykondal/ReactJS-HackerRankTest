import React from "react";
const Table = ({ data, num, page }) => {
    console.log(data, num, page);
    return (
        <div className="card">
            <table data-testid="table">
                <thead>
                    <tr>
                        <th>Country</th>
                        <th>Capital</th>
                    </tr>
                </thead>
                {data.length > 0 && (
                    <tbody data-testid="tableBody">
                        {data.slice(page * num - num, page * num).map((prod) => {
                            return (
                                <tr key={Math.random()}>
                                    <td>{prod.country}</td>
                                    <td>{prod.city}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                )}
            </table>
        </div>
    );
};
export default Table;