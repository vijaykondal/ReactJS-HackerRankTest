import React, { useState } from "react";
import Table from "./table";

const Pagination = ({ data }) => {
    const [page, setPage] = useState(1);
    const [num, setNum] = useState(5);
    const selectNumHandler = (selectedNum) => {
        setNum(selectedNum);
    }
    const selectPageHandler = (selectedPage) => {
        setPage(selectedPage);
    };
    return (
        <>
            <div className="card flex justify-content-center align-items-center px-50 py-40 my-20 input-div">
                <form onSubmit={(e) => e.preventDefault()}>
                    <select data-testid="selectInput" onChange={(e) => selectNumHandler(e.target.value)}>
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                    </select>
                </form>
                <div className="button-div" data-testid="buttonDiv">
                    {[...Array(Math.ceil(data.length / num))].map((_, i) => {
                        return (
                            <button key={Math.random()} onClick={() => selectPageHandler(i + 1)}>
                                {i + 1}
                            </button>
                        );
                    })}
                </div>
            </div>
            <Table data={data} num={num} page={page} />
        </>
    );

};
export default Pagination;