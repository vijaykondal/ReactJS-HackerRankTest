import { useState } from "react";

const Movie = () => {

    const [booked, setBooked] = useState([]);
    const [selectedSeat, setSelectedSeat] = useState([]);

    const bookMovie = () => {
        setBooked([...booked, ...selectedSeat]);
    }
    const onSselectMovie = (row, col) => {
        if (!booked.includes(`${row}${col}`)) {

            setSelectedSeat([...selectedSeat, `${row}${col}`])
        }
    }
    const clearMovie = () => {
        setSelectedSeat([])
    }
    return (
        <div className="layout-row justify-content">
            <h1> Movie List</h1>
            {selectedSeat}

            <button onClick={bookMovie} >Book Movie</button>

            <button onClick={clearMovie} >Clear</button>
            {
                [...Array(4)].map((_, row) => {

                    return [...Array(3)].map((v, col) => {
                        return <div key={`${row}${col}`} onClick={() => { onSselectMovie(row, col) }} className={`movie-ticket ${selectedSeat.includes(`${row}${col}`) ? 'sel-ticket' : ''} ${booked.includes(`${row}${col}`) ? 'is-booked' : ''}`}>{row}{col}</div>
                    })
                })
            }
        </div >
    )
}

export default Movie;