import React, { useState } from "react";

const Profile = () => {

  const [fName, setFname] = useState('Sherlock')
  const [lName, setLname] = useState('Holmes')
  const [email, setEmail] = useState('sherlockholmes@email.com')
  const [editProf, setEditProfile] = useState(false)

  const saveProfile = (e) => {
    e.preventDefault()

    if (!editProf) {
      setEditProfile(true);
      setEmail('')
      setFname('')
      setLname('')
    } else {
      if (fName && lName && email) {
        alert("Profile updated successfully")
        setEditProfile(false);
      } else {
        alert("Please enter all profile fields")
      }
    }
    //if(fName)
  }
  const handeInput = (e) => {
    e.preventDefault()
    console.log(e.target)
    let val = e.target.value;
    if (e.target.name == "fName") {
      setFname(val)
    } else if (e.target.name == "lName") {
      setLname(val)
    } else if (e.target.name == "email") {
      setEmail(val)
    }
  }
  return (
    <div className="w-40 mr-75">
      <div className="card pa-50">
        <h1>User Profile</h1>
        <form>
          <div className="layout-column mb-15">
            <label htmlFor="firstname" className="mb-3">
              First Name
            </label>
            {editProf && <input
              type="text"
              id="firstName"
              name='fName'
              value={fName}
              placeholder="Enter First Name"
              data-testid="firstNameInput"
              onChange={handeInput}
            />}
            {!editProf && <div className="card pa-8" data-testid="firstNameDiv">
              {fName}
            </div>}
          </div>
          <div className="layout-column mb-15">
            <label htmlFor="lastname" className="mb-3">
              Last Name
            </label>
            {editProf && <input
              type="text"
              id="lastName"
              name='lName'
              value={lName}
              placeholder="Enter Last Name"
              data-testid="lastNameInput"
              onChange={handeInput}
            />
            }
            {!editProf && <div className="card pa-8" data-testid="lastNameDiv"> {lName}</div>}
          </div>
          <div className="layout-column mb-30">
            <label htmlFor="email" className="mb-3">
              Email
            </label>
            {editProf && <input
              type="text"
              id="email"
              placeholder="Enter Email"
              data-testid="emailInput"
              value={email}
              name="email"
              onChange={handeInput}
            />}
            {!editProf && <div className="card pa-8" data-testid="emailDiv">{email}</div>}
          </div>
          <div className="layout-row justify-content-end">
            <button onClick={saveProfile} type="submit" className="mx-0" data-testid="changeButton">
              {editProf ? "Save Changes" : "Edit Profile"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Profile;
