import { useEffect, useState } from "react";
import { data2 } from "../assets/data";

import Table from "./customerTable";
const Customer = ({ data }) => {

    const [tableData, setTableData] = useState(data)
    const [input, setInput] = useState('')
    const changeInput = (e) => {
        setInput(e.target.value)
        // setTimeout(() => {
        //     const filteredData = data.filter((item) => {
        //         if (item.name.startsWith(e.target.value) || item.location.startsWith(e.target.value)) {
        //             return item
        //         }
        //     })
        //     setTableData(filteredData)
        // }, 500)
    }

    useEffect(() => {
        let timeOut;
        console.log("befor us", timeOut)
        timeOut = setTimeout(() => {
            if (input) {
                const filteredData = data.filter((item) => {
                    if (item.name.startsWith(input) || item.location.startsWith(input)) {
                        return item
                    }
                })
                setTableData(filteredData)
            } else {
                setTableData(data2)
            }
        }, 500)

        return () => {
            // clear timeout
            clearTimeout(timeOut)

        }

    }, [input])


    return (
        <div>

            <input type='text' onChange={changeInput} />
            <Table data={tableData} />
        </div>
    )
}

export default Customer;