import { useEffect, useRef, useState } from "react";


const DynamicElement = ({ name }) => {
    console.log('props anme', name)
    //  const [input, setInput] = useState(15);
    const [input, setInput] = useState(false);
    const [eArr, setEarr] = useState();
    const fields = [];
    const createElement = () => {
        for (let i = 1; i < input; i++) {
            fields.push(<button key={Math.random()}>{i + 1} </button>);
            setEarr(fields)
        }
    }
    useEffect(() => {
        createElement(input)

    }, [input])


    const changeInput = (e) => {
        setInput(true)
        alert('Heloo')
        e.preventDefault()
        // this.onClick = false
        // createElement()
    }

    const inp1 = useRef()
    const inp2 = useRef()
    const sum = () => {
        console.log(parseInt(inp1.current.value) + parseInt(inp2.current.value))
        inp2.current.value = '3434'
    }
    console.log('test')
    return (<div>
        <h1> Add Dymamic Element</h1>
        <a onClick={changeInput}> link click</a>
        <div onClick={changeInput} className={` seate ${(input) ? 'is-disabled' : ''} ${(input) ? 'Rahuk' : 'test'}`}>click</div>
        {/* <p> add to value</p>
        <input ref={inp1} />
        <input ref={inp2} />
        <button onClick={sum} > cal sum</button>
        <input onChange={(e) => { setInput(e.target.value) }} /> */}
        {/* <input type='text' onChange={(e) => {setInput(e.target.value) }} /> */}
        {/* <input onChange={changeInput} />
        {
            eArr
        } */}




    </div>
    )
}
DynamicElement.defaultProps = {
    name: 'vijay'
}
export default DynamicElement;