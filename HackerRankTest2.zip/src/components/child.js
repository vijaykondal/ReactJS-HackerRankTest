import { useEffect, useLayoutEffect, useState } from "react";

const Child = () => {

    //  const [emp, setEmp] = useState({ name: 'vijay', rollNo: 123 })
    const [emp, setEmp] = useState()
    const [value, setValue] = useState(0)



    // useEffect(() => {
    //     if (value === 0) {
    //         setValue(10 + Math.random() * 2000)
    //     }
    // }, [value])

    useLayoutEffect(() => {
        if (value === 0) {
            setValue(10 + Math.random() * 2000)
        }
    }, [value])

    const changeValue = (e) => {
        setValue(0)
    }
    const inputChange = (e) => {
        setEmp({ ...emp, ...{ name: e.target.value } })
    }
    const inputChange1 = (e) => {
        setEmp({ ...emp, ...{ rollNo: e.target.value } })
    }
    console.log('render', value)
    return (
        <div>test
            <input onChange={inputChange} />
            <input onChange={inputChange1} />
            <button onClick={changeValue} >click {value}</button>
        </div>
    )
}

export default Child;