import logo from './logo.svg';
import './App.css';
import Profile from './components/Profile'
import DynamicElement from './components/Dynamic-element';
import Child from './components/child';
import Pagination from './components/pagination';
import { data, data2 } from './assets/data'
import Customer from './components/customer';
import Movie from './components/movie';
import Navigation from './components/navigation';
function App() {
  return (
    <div className="App">
      <div className="layout-row justify-content-center mt-50">

        <Movie />
        <h2>Navigation</h2>
        <Navigation />
        <Profile />
        <DynamicElement name="Rahul" />
      </div>
      <br>
      </br>
      <br />

      <Child />
      <h2>Pagination</h2>
      <Pagination data={data} />
      <br />

      <h2>Filter customer</h2>
      <Customer data={data2} />
    </div>
  );
}

export default App;
