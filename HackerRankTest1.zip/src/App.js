import logo from './logo.svg';
import './App.css';
import CurrencyConvertor from './currency-converter/currency';

function App() {
  return (
    <div>
    <CurrencyConvertor/>
    </div>
  );
}

export default App;
