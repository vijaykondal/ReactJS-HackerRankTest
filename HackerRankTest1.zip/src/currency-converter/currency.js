import React, { useEffect, useState } from "react";
import {
  exchangeRates,
  defaultCurrency,
  defaultInput,
} from "../data/exchangeRates";
import { preventNegative } from "../utils/preventNegative";
import "./styles.css";

function CurrencyConvertor() {
  const [currency1, setcurrency1] = useState()
  const [input, setInput] = useState(defaultInput)
  const [output, setOutput] = useState()

  const curencyChange = (data) => {
    currentCurrency(data)
    // setcurrency1(data)

    // console.log(input,output)
  }

  const getChangeCur = () => {
    if (input && currency1) {
      // let res= parseFloat(input)/parseFloat(currency);
      let res = parseFloat(input) * parseFloat(currency1.rate)
      setOutput(res.toFixed(3))
    } else {
      setOutput('')
    }
  }
  const currentCurrency = (curr) => {
    let obj = exchangeRates.filter((item) => {
      if (item.currency === curr) {
        return item;
      }
    })
    setcurrency1(obj[0])
  }
  useEffect(() => {
    currentCurrency(defaultCurrency);
    // setcurrency1(obj); 

  }, [])

  useEffect(() => {

    getChangeCur()

  })
  const inputChange = (e) => {
    setInput(e.target.value)
  }
  const clearInput = () => {
    setInput(defaultInput)
  }
  return (
    <div>
      <div className="layout-row justify-content-space-evenly min-height mt-75">
        <div className="layout-column w-35 pa-30 card">
          <select className="mb-10" data-testid="select-currency" defaultValue={defaultCurrency}
            onChange={(e) => curencyChange(e.target.value)}>
            {exchangeRates.map((cur) => (
              <option value={cur.currency} key={cur.rate}>
                {cur.currency}
              </option>
            ))}
          </select>
          <input
            className="h-50"
            type="number"

            onChange={inputChange}
            value={input}
            onKeyDown={preventNegative}
            placeholder={`Enter value in ${currency1?.currency}`}
            data-testid="input-value"
          />
        </div>

        <div className="layout-column w-35 pa-30 card">
          <h3 className="mb-10 mt-0">USD</h3>
          <input
            className="h-50"
            type="number"
            value={output}
            readOnly
            data-testid="converted-value"
          />
        </div>
      </div>

      <div className="layout-row justify-content-center pa-20">
        <button onClick={clearInput} data-testid="clear-values">Clear </button>
      </div>
    </div>
  );
}

export default CurrencyConvertor;
